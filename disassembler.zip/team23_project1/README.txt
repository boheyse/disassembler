This program was created by:
David Heyse (dbh47)
Jacob Hopkins (jah437)


To run the program, open the terminal and in the command line use the command:
"python team_23_project.py -i test#_bin.txt -o team23_out"
